declare global {
    interface Window {
        plausible: ((event: string, ...args: unknown[]) => void) & {
            q?: unknown[][];
        };
        plausibleExcludePaths?: RegExp[];
    }
}
interface RouteUpdateArgs {
    location: Location;
    previousLocation: Location | null;
}
declare const _default: {
    onRouteUpdate({ location }: RouteUpdateArgs): void;
} | null;
export default _default;
//# sourceMappingURL=analytics.d.ts.map