export interface PluginOptions {
    /** The domain of your website as configured in Plausible (required) */
    domain: string;
    /** Custom domain if self-hosting Plausible (defaults to "plausible.io") */
    customDomain?: string;
    /**
     * Paths to exclude from pageview tracking. Each entry is used as a RegExp
     * pattern (e.g. "^/admin" or "private").
     *
     * NOTE: If you were previously passing regex-literal strings such as
     * "/admin/" you should now pass the bare pattern: "admin".
     */
    excludePaths?: string[];
}
//# sourceMappingURL=types.d.ts.map