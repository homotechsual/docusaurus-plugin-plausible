import type { LoadContext, Plugin } from '@docusaurus/types';
import type { PluginOptions } from './types.js';
export default function pluginPlausible(_context: LoadContext, options: PluginOptions): Plugin<void>;
export type { PluginOptions };
//# sourceMappingURL=index.d.ts.map